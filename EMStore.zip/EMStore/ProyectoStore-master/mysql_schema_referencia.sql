-- Base de datos para EMStore.
-- Ejecutar este script en MySQL Workbench, phpMyAdmin o cliente MySQL.

CREATE DATABASE IF NOT EXISTS emstore
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE emstore;

CREATE TABLE IF NOT EXISTS productos (
    codigo VARCHAR(30) PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    categoria VARCHAR(80) NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    stock INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS pedidos (
    id_pedido VARCHAR(30) PRIMARY KEY,
    cliente VARCHAR(120) NOT NULL,
    fecha DATE NOT NULL,
    total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    estado VARCHAR(30) NOT NULL DEFAULT 'Pendiente'
);

CREATE TABLE IF NOT EXISTS detalle_pedido (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_pedido VARCHAR(30) NOT NULL,
    codigo_producto VARCHAR(30) NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    INDEX idx_detalle_id_pedido (id_pedido),
    INDEX idx_detalle_codigo_producto (codigo_producto),
    CONSTRAINT fk_detalle_pedido
        FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido)
        ON DELETE CASCADE,
    CONSTRAINT fk_detalle_producto
        FOREIGN KEY (codigo_producto) REFERENCES productos(codigo)
);

CREATE TABLE IF NOT EXISTS movimientos (
    id_movimiento INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATE NOT NULL,
    tipo VARCHAR(20) NOT NULL,
    producto VARCHAR(120) NOT NULL,
    cantidad INT NOT NULL,
    usuario VARCHAR(120) NOT NULL,
    INDEX idx_movimientos_fecha (fecha),
    INDEX idx_movimientos_tipo (tipo)
);

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ems.Controladores;

import ems.Estructuras.ListaEnlazada;
import ems.Modelo.Movimiento;
import ems.Persistencia.PersistenciaDatos;

public class DatosSistema {
    
    public static ControlProducto controlProducto = new ControlProducto();

    public static ControlPedido controlPedido = new ControlPedido();
    
    public static int totalEntradas = 0;
    public static int totalSalidas = 0;
    
    public static ListaEnlazada<Movimiento> movimientos = new ListaEnlazada<>();

    static {
        PersistenciaDatos.cargarDatosIniciales();
    }

    public static void registrarMovimiento(Movimiento movimiento) {
        movimientos.agregar(movimiento);
        PersistenciaDatos.guardarMovimiento(movimiento);
    }

    public static void registrarMovimientoCargado(Movimiento movimiento) {
        movimientos.agregar(movimiento);

        if ("ENTRADA".equalsIgnoreCase(movimiento.getTipo())) {
            totalEntradas += movimiento.getCantidad();
        } else if ("SALIDA".equalsIgnoreCase(movimiento.getTipo())) {
            totalSalidas += movimiento.getCantidad();
        }
    }
    
}

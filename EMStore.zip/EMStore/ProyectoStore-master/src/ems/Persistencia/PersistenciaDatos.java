package ems.Persistencia;

import ems.Controladores.DatosSistema;
import ems.Estructuras.ListaEnlazada;
import ems.Estructuras.Nodo;
import ems.Modelo.Movimiento;
import ems.Modelo.Pedido;
import ems.Modelo.Producto;
import java.sql.SQLException;

public class PersistenciaDatos {

    private static final RepositorioMySQL REPOSITORIO = new RepositorioMySQL();

    private PersistenciaDatos() {
    }

    public static void cargarDatosIniciales() {
        try {
            ListaEnlazada<Producto> productos = REPOSITORIO.cargarProductos();
            Nodo<Producto> producto = productos.getCabeza();

            while (producto != null) {
                DatosSistema.controlProducto.cargarProducto(producto.getDato());
                producto = producto.getSiguiente();
            }

            ListaEnlazada<Pedido> pedidos = REPOSITORIO.cargarPedidos();
            Nodo<Pedido> pedido = pedidos.getCabeza();

            while (pedido != null) {
                DatosSistema.controlPedido.cargarPedido(pedido.getDato());
                pedido = pedido.getSiguiente();
            }

            ListaEnlazada<Movimiento> movimientos = REPOSITORIO.cargarMovimientos();
            Nodo<Movimiento> movimiento = movimientos.getCabeza();

            while (movimiento != null) {
                DatosSistema.registrarMovimientoCargado(movimiento.getDato());
                movimiento = movimiento.getSiguiente();
            }
        } catch (SQLException ex) {
            System.err.println("Persistencia MySQL no disponible: " + ex.getMessage());
        }
    }

    public static void guardarProducto(Producto producto) {
        ejecutar(() -> REPOSITORIO.guardarProducto(producto));
    }

    public static void eliminarProducto(String codigo) {
        ejecutar(() -> REPOSITORIO.eliminarProducto(codigo));
    }

    public static void guardarPedido(Pedido pedido) {
        ejecutar(() -> REPOSITORIO.guardarPedido(pedido));
    }

    public static void actualizarEstadoPedido(Pedido pedido) {
        ejecutar(() -> REPOSITORIO.actualizarEstadoPedido(pedido));
    }

    public static void guardarMovimiento(Movimiento movimiento) {
        ejecutar(() -> REPOSITORIO.guardarMovimiento(movimiento));
    }

    private static void ejecutar(OperacionPersistencia operacion) {
        try {
            operacion.ejecutar();
        } catch (SQLException ex) {
            System.err.println("No se pudo sincronizar con MySQL: " + ex.getMessage());
        }
    }

    private interface OperacionPersistencia {
        void ejecutar() throws SQLException;
    }
}

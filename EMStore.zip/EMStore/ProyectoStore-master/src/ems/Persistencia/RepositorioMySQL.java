package ems.Persistencia;

import ems.Controladores.DatosSistema;
import ems.Estructuras.ListaEnlazada;
import ems.Estructuras.Nodo;
import ems.Modelo.DetallePedido;
import ems.Modelo.Movimiento;
import ems.Modelo.Pedido;
import ems.Modelo.Producto;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RepositorioMySQL {

    public ListaEnlazada<Producto> cargarProductos() throws SQLException {
        ListaEnlazada<Producto> productos = new ListaEnlazada<>();
        String sql = "SELECT codigo, nombre, categoria, precio, stock FROM productos";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                productos.agregar(new Producto(
                        rs.getString("codigo"),
                        rs.getString("nombre"),
                        rs.getString("categoria"),
                        rs.getDouble("precio"),
                        rs.getInt("stock")
                ));
            }
        }

        return productos;
    }

    public ListaEnlazada<Pedido> cargarPedidos() throws SQLException {
        ListaEnlazada<Pedido> pedidos = new ListaEnlazada<>();
        String sql = "SELECT id_pedido, cliente, fecha, total, estado FROM pedidos";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Pedido pedido = new Pedido(
                        rs.getString("id_pedido"),
                        rs.getString("cliente"),
                        rs.getString("fecha"),
                        rs.getDouble("total"),
                        rs.getString("estado")
                );

                cargarDetalles(cn, pedido);
                pedidos.agregar(pedido);
            }
        }

        return pedidos;
    }

    public ListaEnlazada<Movimiento> cargarMovimientos() throws SQLException {
        ListaEnlazada<Movimiento> movimientos = new ListaEnlazada<>();
        String sql = "SELECT fecha, tipo, producto, cantidad, usuario FROM movimientos ORDER BY id_movimiento";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                movimientos.agregar(new Movimiento(
                        rs.getString("fecha"),
                        rs.getString("tipo"),
                        rs.getString("producto"),
                        rs.getInt("cantidad"),
                        rs.getString("usuario")
                ));
            }
        }

        return movimientos;
    }

    public void guardarProducto(Producto producto) throws SQLException {
        String sql = "INSERT INTO productos (codigo, nombre, categoria, precio, stock) "
                + "VALUES (?, ?, ?, ?, ?) "
                + "ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), categoria = VALUES(categoria), "
                + "precio = VALUES(precio), stock = VALUES(stock)";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, producto.getCodigo());
            ps.setString(2, producto.getNombre());
            ps.setString(3, producto.getCategoria());
            ps.setDouble(4, producto.getPrecio());
            ps.setInt(5, producto.getStock());
            ps.executeUpdate();
        }
    }

    public void eliminarProducto(String codigo) throws SQLException {
        String sql = "DELETE FROM productos WHERE codigo = ?";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, codigo);
            ps.executeUpdate();
        }
    }

    public void guardarPedido(Pedido pedido) throws SQLException {
        String sqlPedido = "INSERT INTO pedidos (id_pedido, cliente, fecha, total, estado) "
                + "VALUES (?, ?, ?, ?, ?) "
                + "ON DUPLICATE KEY UPDATE cliente = VALUES(cliente), fecha = VALUES(fecha), "
                + "total = VALUES(total), estado = VALUES(estado)";
        String sqlEliminarDetalles = "DELETE FROM detalle_pedido WHERE id_pedido = ?";
        String sqlDetalle = "INSERT INTO detalle_pedido (id_pedido, codigo_producto, cantidad, subtotal) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection cn = ConexionMySQL.obtenerConexion()) {
            cn.setAutoCommit(false);

            try (PreparedStatement psPedido = cn.prepareStatement(sqlPedido);
                 PreparedStatement psEliminar = cn.prepareStatement(sqlEliminarDetalles);
                 PreparedStatement psDetalle = cn.prepareStatement(sqlDetalle)) {

                psPedido.setString(1, pedido.getIdPedido());
                psPedido.setString(2, pedido.getCliente());
                psPedido.setDate(3, Date.valueOf(pedido.getFecha()));
                psPedido.setDouble(4, pedido.getTotal());
                psPedido.setString(5, pedido.getEstado());
                psPedido.executeUpdate();

                psEliminar.setString(1, pedido.getIdPedido());
                psEliminar.executeUpdate();

                Nodo<DetallePedido> detalle = pedido.getDetalles().getCabeza();

                while (detalle != null) {
                    DetallePedido d = detalle.getDato();
                    psDetalle.setString(1, pedido.getIdPedido());
                    psDetalle.setString(2, d.getProducto().getCodigo());
                    psDetalle.setInt(3, d.getCantidad());
                    psDetalle.setDouble(4, d.getSubtotal());
                    psDetalle.addBatch();
                    detalle = detalle.getSiguiente();
                }

                psDetalle.executeBatch();
                cn.commit();
            } catch (SQLException ex) {
                cn.rollback();
                throw ex;
            } finally {
                cn.setAutoCommit(true);
            }
        }
    }

    public void actualizarEstadoPedido(Pedido pedido) throws SQLException {
        String sql = "UPDATE pedidos SET estado = ? WHERE id_pedido = ?";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, pedido.getEstado());
            ps.setString(2, pedido.getIdPedido());
            ps.executeUpdate();
        }
    }

    public void guardarMovimiento(Movimiento movimiento) throws SQLException {
        String sql = "INSERT INTO movimientos (fecha, tipo, producto, cantidad, usuario) VALUES (?, ?, ?, ?, ?)";

        try (Connection cn = ConexionMySQL.obtenerConexion();
             PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setDate(1, Date.valueOf(movimiento.getFecha()));
            ps.setString(2, movimiento.getTipo());
            ps.setString(3, movimiento.getProducto());
            ps.setInt(4, movimiento.getCantidad());
            ps.setString(5, movimiento.getUsuario());
            ps.executeUpdate();
        }
    }

    private void cargarDetalles(Connection cn, Pedido pedido) throws SQLException {
        String sql = "SELECT codigo_producto, cantidad FROM detalle_pedido WHERE id_pedido = ?";

        try (PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setString(1, pedido.getIdPedido());

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto producto = DatosSistema.controlProducto.buscarPorCodigo(rs.getString("codigo_producto"));

                    if (producto != null) {
                        pedido.cargarDetalle(new DetallePedido(producto, rs.getInt("cantidad")));
                    }
                }
            }
        }
    }
}

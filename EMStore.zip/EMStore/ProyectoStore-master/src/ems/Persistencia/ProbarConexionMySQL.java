package ems.Persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProbarConexionMySQL {

    public static void main(String[] args) {
        try (Connection cn = ConexionMySQL.obtenerConexion()) {
            probarTabla(cn, "productos");
            probarTabla(cn, "pedidos");
            probarTabla(cn, "detalle_pedido");
            probarTabla(cn, "movimientos");

            System.out.println("Conexion MySQL correcta. Base y tablas disponibles.");
        } catch (Exception ex) {
            System.err.println("No se pudo conectar a MySQL.");
            System.err.println(ex.getMessage());
            ex.printStackTrace();
        }
    }

    private static void probarTabla(Connection cn, String tabla) throws Exception {
        String sql = "SELECT COUNT(*) FROM " + tabla;

        try (PreparedStatement ps = cn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                System.out.println(tabla + ": " + rs.getInt(1) + " registros");
            }
        }
    }
}

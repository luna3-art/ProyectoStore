package ems.Persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConexionMySQL {

    private static final String URL_DEFAULT = "jdbc:mysql://localhost:3306/emstore?useSSL=false&serverTimezone=UTC&connectTimeout=3000&socketTimeout=3000";
    private static final String ARCHIVO_CONFIG = "config/db.properties";

    private ConexionMySQL() {
    }

    public static Connection obtenerConexion() throws SQLException {
        Properties archivo = cargarConfiguracion();
        String url = obtenerConfiguracion(archivo, "db.url", "DB_URL", URL_DEFAULT);
        String usuario = obtenerConfiguracion(archivo, "db.user", "DB_USER", "root");
        String password = obtenerConfiguracion(archivo, "db.password", "DB_PASSWORD", "");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("No se encontro el driver JDBC de MySQL. Agregue mysql-connector-j al classpath.", ex);
        }

        return DriverManager.getConnection(url, usuario, password);
    }

    private static String obtenerConfiguracion(Properties archivo, String propiedad, String variableEntorno, String valorDefecto) {
        String valor = System.getProperty(propiedad);

        if (valor == null || valor.isBlank()) {
            valor = System.getenv(variableEntorno);
        }

        if ((valor == null || valor.isBlank()) && archivo != null) {
            valor = archivo.getProperty(propiedad);
        }

        if (valor == null || valor.isBlank()) {
            valor = valorDefecto;
        }

        return valor;
    }

    private static Properties cargarConfiguracion() {
        Properties propiedades = new Properties();

        try (FileInputStream entrada = new FileInputStream(ARCHIVO_CONFIG)) {
            propiedades.load(entrada);
            return propiedades;
        } catch (IOException ex) {
            return null;
        }
    }
}

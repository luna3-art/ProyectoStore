# Configuracion MySQL

## 1. Crear la base de datos

Ejecuta el archivo `mysql_schema_referencia.sql` en MySQL Workbench, phpMyAdmin o desde consola MySQL.

Desde consola seria:

```bash
mysql -u root -p < mysql_schema_referencia.sql
```

## 2. Configurar la conexion del aplicativo

La aplicacion lee primero este archivo:

```text
config/db.properties
```

Edita ahi tu usuario y password de MySQL:

```text
db.url=jdbc:mysql://localhost:3306/emstore?useSSL=false&serverTimezone=UTC&connectTimeout=3000&socketTimeout=3000
db.user=root
db.password=tu_password
```

Tambien puedes pasarlos como propiedades JVM:

```bash
-Ddb.url=jdbc:mysql://localhost:3306/emstore?useSSL=false&serverTimezone=UTC&connectTimeout=3000&socketTimeout=3000
-Ddb.user=root
-Ddb.password=tu_password
```

## 3. Agregar el driver

Agrega `mysql-connector-j` al classpath del proyecto NetBeans para que Java pueda conectarse a MySQL.

Este proyecto ya espera el archivo en:

```text
lib/mysql-connector-j.jar
```

Puedes crear la carpeta `lib` en la raiz del proyecto y copiar ahi el driver con ese nombre.

Si usas NetBeans tambien puedes hacerlo desde:

```text
Proyecto > Properties > Libraries > Add JAR/Folder
```

## 4. Usuario de prueba del sistema

El login del aplicativo todavia usa credenciales fijas en codigo:

```text
Usuario: admin
Password: 123
```
